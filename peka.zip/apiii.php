<?php
// Ambil pesan dari POST
$subjek = $_POST['subjek'] ?? '';
$pesan  = $_POST['pesan'] ?? '';

include 'ser.php';

// Baca semua ID Telegram dari data.json
$read = file_get_contents('fox/data.json');
$json = json_decode($read, true);

foreach ($json as $key => $userData) {
    $chat_id = $userData['email']; // sekarang 'email' itu ID Telegram
    $text = "📌 *$subjek*\n\n$pesan";

    // Kirim ke Telegram
    $url = "https://api.telegram.org/bot$sender/sendMessage";
    $post_fields = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'Markdown'
    ];

    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_POST, 1); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch); 
    curl_close($ch);

    // Kurangi jumlahResult
    if ($result) {
        $json[$key]['jumlahResult'] -= 1;
        if ($json[$key]['jumlahResult'] <= 0) {
            unset($json[$key]);
        }
    }
}

// Simpan kembali data.json
file_put_contents('fox/data.json', json_encode(array_values($json)));
?>