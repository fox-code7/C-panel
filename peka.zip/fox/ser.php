<?php 

$nik = "Results FOX7CODE";
$sender = "owners@fox.dev";
?>