<?php
// Nama yang muncul di panel
$nik = "Results FOX7CODE";

// Token bot Telegram (digunakan untuk kirim pesan)
$sender = "8521177599:AAE7l40BjMjEwZB_TwmdAeVF1A_KaTgX8rw"; // ganti dengan token bot kamu
?>